package com.example.quizserver.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OpenAiFeedbackService {
    private static final String OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses";

    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    private final String apiKey;
    private final String model;

    public OpenAiFeedbackService(
            ObjectMapper objectMapper,
            @Value("${openai.api.key:}") String apiKey,
            @Value("${openai.model:gpt-4.1-mini}") String model
    ) {
        this.objectMapper = objectMapper;
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.model = model;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(20))
                .build();
    }

    public String generateFeedback(AiFeedbackRequest request) {
        if (!isConfigured()) {
            return fallbackFeedback(request);
        }

        try {
            String prompt = buildPrompt(request);
            String requestBody = objectMapper.writeValueAsString(
                    new OpenAiRequest(model, prompt, 220)
            );

            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(OPENAI_RESPONSES_URL))
                    .timeout(Duration.ofSeconds(45))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                return fallbackFeedback(request);
            }

            String feedback = extractFeedback(response.body());
            return feedback == null || feedback.isBlank() ? fallbackFeedback(request) : feedback.trim();
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            return fallbackFeedback(request);
        }
    }

    private boolean isConfigured() {
        return !apiKey.isBlank() && !apiKey.contains("your_openai_api_key");
    }

    private String buildPrompt(AiFeedbackRequest request) {
        String title = request.quizTitle() == null || request.quizTitle().isBlank() ? "Quiz" : request.quizTitle();
        int score = request.score() == null ? 0 : request.score();
        int totalQuestions = request.totalQuestions() == null ? 0 : request.totalQuestions();
        List<AiFeedbackAnswer> answers = request.answers() == null ? List.of() : request.answers();

        String answeredCorrectly = answers.stream()
                .filter(AiFeedbackAnswer::correct)
                .map(answer -> "- " + safe(answer.question()))
                .collect(Collectors.joining("\n"));

        String answeredIncorrectly = answers.stream()
                .filter(answer -> !answer.correct())
                .map(answer -> "- Question: " + safe(answer.question())
                        + " | User answered: " + safe(answer.userAnswer())
                        + " | Correct answer: " + safe(answer.correctAnswer()))
                .collect(Collectors.joining("\n"));

        return """
                You are a friendly quiz tutor.
                The user completed the quiz "%s" and scored %d out of %d.

                Correct answers:
                %s

                Incorrect answers:
                %s

                Write a short response in 3 to 4 sentences.
                Start positive, explain one missed concept if there is one, and end with motivation for the next quiz.
                Keep it concise, supportive, and easy to read.
                """.formatted(
                title,
                score,
                totalQuestions,
                answeredCorrectly.isBlank() ? "- None" : answeredCorrectly,
                answeredIncorrectly.isBlank() ? "- None" : answeredIncorrectly
        );
    }

    private String extractFeedback(String responseBody) throws IOException {
        JsonNode root = objectMapper.readTree(responseBody);
        JsonNode outputText = root.path("output_text");
        if (outputText.isTextual() && !outputText.asText().isBlank()) {
            return outputText.asText();
        }

        JsonNode output = root.path("output");
        if (!output.isArray()) {
            return null;
        }

        for (JsonNode item : output) {
            JsonNode content = item.path("content");
            if (!content.isArray()) {
                continue;
            }

            for (JsonNode contentItem : content) {
                JsonNode text = contentItem.path("text");
                if (text.isTextual() && !text.asText().isBlank()) {
                    return text.asText();
                }
            }
        }

        return null;
    }

    private String fallbackFeedback(AiFeedbackRequest request) {
        int score = request.score() == null ? 0 : request.score();
        int totalQuestions = request.totalQuestions() == null ? 0 : request.totalQuestions();
        if (totalQuestions == 0) {
            return "Nice work finishing the quiz. Keep practicing and come back for another round.";
        }

        if (score == totalQuestions) {
            return "Excellent work. You got every question right and showed strong understanding across the quiz.";
        }

        if (score >= Math.ceil(totalQuestions * 0.7)) {
            return "Great job. You answered most questions correctly and are building solid quiz skills.";
        }

        return "Good effort finishing the quiz. Review the missed questions and try again to strengthen your understanding.";
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "N/A" : value;
    }

    private record OpenAiRequest(
            String model,
            String input,
            Integer max_output_tokens
    ) {
    }
}
