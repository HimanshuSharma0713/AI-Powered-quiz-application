INSERT INTO quizzes (title, description, subject, created_by, is_active) VALUES
('Mathematics Essentials', 'Practice arithmetic, algebra, and number sense fundamentals.', 'Mathematics', 'admin', TRUE),
('Science Foundations', 'Warm up with core science ideas across physics, biology, and chemistry.', 'Science', 'admin', TRUE),
('World Geography Explorer', 'Build confidence with capitals, continents, and global landmarks.', 'Geography', 'admin', TRUE),
('Computer Science Basics', 'Review programming, logic, and computer fundamentals.', 'Computer Science', 'admin', TRUE);

INSERT INTO questions (quiz_id, question_text, choice_a, choice_b, choice_c, choice_d, correct_answer) VALUES
((SELECT id FROM quizzes WHERE title = 'Mathematics Essentials'),
 'What is 15% of 200?', '15', '20', '25', '30', '30'),
((SELECT id FROM quizzes WHERE title = 'Mathematics Essentials'),
 'Solve: 3x = 21', '5', '6', '7', '8', '7'),
((SELECT id FROM quizzes WHERE title = 'Mathematics Essentials'),
 'Which number is prime?', '21', '27', '29', '33', '29'),

((SELECT id FROM quizzes WHERE title = 'Science Foundations'),
 'What gas do plants absorb from the atmosphere?', 'Oxygen', 'Nitrogen', 'Carbon Dioxide', 'Hydrogen', 'Carbon Dioxide'),
((SELECT id FROM quizzes WHERE title = 'Science Foundations'),
 'Which part of the cell contains genetic material?', 'Membrane', 'Nucleus', 'Ribosome', 'Cytoplasm', 'Nucleus'),
((SELECT id FROM quizzes WHERE title = 'Science Foundations'),
 'What force pulls objects toward Earth?', 'Magnetism', 'Friction', 'Gravity', 'Electricity', 'Gravity'),

((SELECT id FROM quizzes WHERE title = 'World Geography Explorer'),
 'Which continent is Egypt located in?', 'Asia', 'Africa', 'Europe', 'South America', 'Africa'),
((SELECT id FROM quizzes WHERE title = 'World Geography Explorer'),
 'What is the capital of Japan?', 'Seoul', 'Beijing', 'Tokyo', 'Bangkok', 'Tokyo'),
((SELECT id FROM quizzes WHERE title = 'World Geography Explorer'),
 'Which ocean is the largest?', 'Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean', 'Pacific Ocean'),

((SELECT id FROM quizzes WHERE title = 'Computer Science Basics'),
 'Which data structure uses First In, First Out order?', 'Stack', 'Queue', 'Tree', 'Graph', 'Queue'),
((SELECT id FROM quizzes WHERE title = 'Computer Science Basics'),
 'Binary uses which two digits?', '0 and 1', '1 and 2', '2 and 3', '8 and 9', '0 and 1'),
((SELECT id FROM quizzes WHERE title = 'Computer Science Basics'),
 'Which language is primarily used for styling web pages?', 'HTML', 'Python', 'CSS', 'SQL', 'CSS');
