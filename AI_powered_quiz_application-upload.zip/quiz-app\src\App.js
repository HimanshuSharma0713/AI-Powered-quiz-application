import React, { useState, useEffect } from 'react';

function App() {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [showLogin, setShowLogin] = useState(true);
  const [isRegistering, setIsRegistering] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [quizHistory, setQuizHistory] = useState([]);

  // Quiz state management
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState([]);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [aiFeedback, setAiFeedback] = useState('');
  const [isLoadingFeedback, setIsLoadingFeedback] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Admin state
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [allUsers, setAllUsers] = useState([]);
  const [userStats, setUserStats] = useState({});

  // Quiz management state
  const [quizzes, setQuizzes] = useState([]);
  const [quizSearchTerm, setQuizSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('All Subjects');
  const [dashboardTab, setDashboardTab] = useState('subjects');

  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [showQuizCreator, setShowQuizCreator] = useState(false);
  const [editingQuiz, setEditingQuiz] = useState(null);
  const [showQuizEditor, setShowQuizEditor] = useState(false);

  // Users list for admin view
  const [users, setUsers] = useState([]);

  const subjectOptions = [
    'General Knowledge',
    'Mathematics',
    'Science',
    'Geography',
    'History',
    'Computer Science',
    'Language Arts'
  ];

  // Helpers
  const fetchQuizzes = async () => {
    try {
      const res = await fetch('/api/quizzes');
      if (res.ok) {
        const data = await res.json();
        setQuizzes(data);
      }
    } catch (e) {
      console.error('Failed to fetch quizzes', e);
    }
  };

  const fetchUserHistory = async (userId) => {
    try {
      const res = await fetch(`/api/results/user/${userId}`);
      if (res.ok) {
        const data = await res.json();
        setQuizHistory(data);
        setCurrentUser(prev => {
          if (!prev) {
            return prev;
          }

          const updatedUser = { ...prev, quizHistory: data };
          localStorage.setItem('currentUser', JSON.stringify(updatedUser));
          return updatedUser;
        });
      }
    } catch (e) {
      console.error('Failed to fetch user history', e);
    }
  };

  const fetchAdminUsers = async () => {
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch (e) {
      console.error('Failed to fetch users', e);
    }
  };

  // Check for existing session on app load
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
      setQuizHistory(user.quizHistory || []);
      setIsAuthenticated(true);
      setShowLogin(false);
      fetchQuizzes();
      fetchUserHistory(user.id);
    } else {
      fetchQuizzes();
    }
  }, []);

  useEffect(() => {
    if (!selectedQuiz || quizCompleted) {
      return undefined;
    }

    const timer = window.setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);

    return () => window.clearInterval(timer);
  }, [selectedQuiz, quizCompleted]);

  // Handle login
  const handleLogin = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const username = formData.get('username');
    const password = formData.get('password');

    fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    }).then(async (res) => {
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Login failed');
      }
      return res.json();
    }).then((user) => {
      const normalizedUser = { ...user, quizHistory: [] };
      setCurrentUser(normalizedUser);
      setQuizHistory([]);
      setIsAuthenticated(true);
      setShowLogin(false);
      setLoginError('');
      localStorage.setItem('currentUser', JSON.stringify(normalizedUser));
      fetchUserHistory(user.id);
      fetchQuizzes();
    }).catch((e) => {
      setLoginError(e.message);
    });
  };

  // Handle registration
  const handleRegister = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const username = formData.get('username');
    const password = formData.get('password');
    const email = formData.get('email');

    fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, email })
    }).then(async (res) => {
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Registration failed');
      }
      return res.json();
    }).then((user) => {
      const normalizedUser = { ...user, quizHistory: [] };
      setCurrentUser(normalizedUser);
      setQuizHistory([]);
      setIsAuthenticated(true);
      setShowLogin(false);
      setLoginError('');
      setIsRegistering(false);
      localStorage.setItem('currentUser', JSON.stringify(normalizedUser));
    }).catch((e) => {
      setLoginError(e.message);
    });
  };

  // Handle logout
  const handleLogout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    setShowLogin(true);
    setShowAdminPanel(false);
    setSelectedQuiz(null);
    setQuizHistory([]);
    setCurrentQuestionIndex(0);
    setUserAnswers([]);
    setQuizCompleted(false);
    setScore(0);
    setAiFeedback('');
    setElapsedSeconds(0);
    localStorage.removeItem('currentUser');
  };

  // Save quiz results to user history
  const saveQuizResults = (finalScore, answers, quizId) => {
    const totalQuestions = selectedQuiz ? selectedQuiz.questions.length : answers.length;
    const optimisticHistoryEntry = {
      id: `temp-${Date.now()}`,
      quizId,
      quizTitle: selectedQuiz ? selectedQuiz.title : 'Quiz',
      score: finalScore,
      totalQuestions,
      date: new Date().toISOString()
    };

    setQuizHistory(prev => [optimisticHistoryEntry, ...prev]);

    setCurrentUser(prev => {
      if (!prev) {
        return prev;
      }

      const updatedUser = {
        ...prev,
          quizHistory: [optimisticHistoryEntry, ...(prev.quizHistory || [])]
      };
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      return updatedUser;
    });

    fetch('/api/results', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: currentUser.id, quizId, score: finalScore, totalQuestions })
    }).then(() => {
      fetchUserHistory(currentUser.id);
    }).catch(e => console.error('Failed to save results', e));
  };

  // Handle answer selection
  const handleAnswerSelect = (selectedAnswer) => {
    const newUserAnswers = [...userAnswers, selectedAnswer];
    setUserAnswers(newUserAnswers);

    // Move to next question or complete quiz
    if (currentQuestionIndex < selectedQuiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Quiz completed - calculate score and get AI feedback
      const finalScore = calculateScore(newUserAnswers);
      setScore(finalScore);
      setQuizCompleted(true);
      saveQuizResults(finalScore, newUserAnswers, selectedQuiz.id);
      generateAIFeedback(newUserAnswers, finalScore);
    }
  };

  // Calculate final score
  const calculateScore = (answers) => {
    let correctCount = 0;
    answers.forEach((answer, index) => {
      if (answer === selectedQuiz.questions[index].correctAnswer) {
        correctCount++;
      }
    });
    return correctCount;
  };

  // Generate AI feedback through the backend AI endpoint
  const generateAIFeedback = async (answers, finalScore) => {
    setIsLoadingFeedback(true);
    
    try {
      const answerReview = answers.map((answer, index) => {
        const question = selectedQuiz.questions[index];
        return {
          question: question.question,
          userAnswer: answer,
          correctAnswer: question.correctAnswer,
          correct: answer === question.correctAnswer
        };
      });

      const response = await fetch('/api/ai/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          quizTitle: selectedQuiz.title,
          score: finalScore,
          totalQuestions: selectedQuiz.questions.length,
          answers: answerReview
        })
      });

      if (response.ok) {
        const data = await response.json();
        setAiFeedback(data.feedback);
      } else {
        // Fallback feedback if API call fails
        setAiFeedback(`Great job completing the quiz! You scored ${finalScore} out of ${selectedQuiz ? selectedQuiz.questions.length : 0}. Keep up the great work and continue learning!`);
      }
    } catch (error) {
      console.error('Error generating AI feedback:', error);
      // Fallback feedback
      setAiFeedback(`Congratulations on completing the quiz! You scored ${finalScore} out of ${selectedQuiz ? selectedQuiz.questions.length : 0}. Well done!`);
    } finally {
      setIsLoadingFeedback(false);
    }
  };

  // Reset quiz
  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setUserAnswers([]);
    setQuizCompleted(false);
    setScore(0);
    setAiFeedback('');
    setIsLoadingFeedback(false);
    setElapsedSeconds(0);
  };

  const goToDashboard = () => {
    resetQuiz();
    setSelectedQuiz(null);
    setShowAdminPanel(false);
    fetchQuizzes();
    if (currentUser?.id) {
      fetchUserHistory(currentUser.id);
    }
  };

  const formatTime = (totalSeconds) => {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Admin functions
  const toggleAdminPanel = () => {
    const next = !showAdminPanel;
    setShowAdminPanel(next);
    if (next) {
      fetchAdminUsers();
    }
  };

  const deleteUser = (userId) => {
    if (userId === currentUser.id) {
      alert('You cannot delete your own account!');
      return;
    }
    setUsers(users.filter(user => user.id !== userId));
  };

  // Quiz management functions
  const createQuiz = (quizData) => {
    const payload = {
      title: quizData.title,
      description: quizData.description,
      subject: quizData.subject,
      createdBy: currentUser.username,
      questions: quizData.questions.map(q => ({ question: q.question, choices: q.choices, correctAnswer: q.correctAnswer }))
    };
    fetch('/api/quizzes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(async (res) => {
      if (!res.ok) throw new Error('Failed to create quiz');
      await fetchQuizzes();
      setShowQuizCreator(false);
      setQuizData({
        title: '',
        description: '',
        subject: 'General Knowledge',
        questions: [
          { id: 1, question: '', choices: ['', '', '', ''], correctAnswer: '' }
        ]
      });
    }).catch(e => alert(e.message));
  };

  const updateQuiz = (quizId, updatedData) => {
    setQuizzes(quizzes.map(quiz => 
      quiz.id === quizId ? { ...quiz, ...updatedData } : quiz
    ));
    setShowQuizEditor(false);
    setEditingQuiz(null);
  };

  const deleteQuiz = (quizId) => {
    if (window.confirm('Are you sure you want to delete this quiz?')) {
      fetch(`/api/quizzes/${quizId}`, { method: 'DELETE' })
        .then(() => fetchQuizzes())
        .catch(e => alert('Failed to delete quiz'));
    }
  };

  const toggleQuizStatus = (quizId) => {
    fetch(`/api/quizzes/${quizId}/toggle`, { method: 'POST' })
      .then(() => fetchQuizzes())
      .catch(e => alert('Failed to toggle quiz status'));
  };

  const startQuiz = (quiz) => {
    // Ensure we have full quiz with questions
    fetch(`/api/quizzes/${quiz.id}`)
      .then(res => res.json())
      .then(fullQuiz => {
        setSelectedQuiz(fullQuiz);
        setCurrentQuestionIndex(0);
        setUserAnswers([]);
        setQuizCompleted(false);
        setScore(0);
        setAiFeedback('');
        setElapsedSeconds(0);
      })
      .catch(() => {
        // fallback to provided quiz if fetch fails
        setSelectedQuiz(quiz);
        setCurrentQuestionIndex(0);
        setUserAnswers([]);
        setQuizCompleted(false);
        setScore(0);
        setAiFeedback('');
        setElapsedSeconds(0);
      });
  };

  // Render login/register form
  const renderAuthForm = () => {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              AI Quiz App
            </h1>
            <p className="text-gray-600">
              {isRegistering ? 'Create your account' : 'Sign in to continue'}
            </p>
          </div>

          {loginError && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
              {loginError}
            </div>
          )}

          <form onSubmit={isRegistering ? handleRegister : handleLogin}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  name="username"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter username"
                />
              </div>

              {isRegistering && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter email"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  name="password"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter password"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-md transition-colors duration-200"
              >
                {isRegistering ? 'Register' : 'Sign In'}
              </button>
            </div>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsRegistering(!isRegistering);
                setLoginError('');
              }}
              className="text-blue-600 hover:text-blue-700 text-sm"
            >
              {isRegistering ? 'Already have an account? Sign in' : "Don't have an account? Register"}
            </button>
          </div>

          {!isRegistering && (
            <div className="mt-4 text-center text-sm text-gray-600">
              <p>Demo accounts:</p>
              <p><strong>Admin:</strong> admin / admin123</p>
              <p><strong>User:</strong> user1 / user123</p>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Render admin panel
  const renderAdminPanel = () => {
    return (
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Admin Panel</h2>
          <div className="flex space-x-2">
            <button
              onClick={() => setShowQuizCreator(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md"
            >
              Create Quiz
            </button>
            <button
              onClick={toggleAdminPanel}
              className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md"
            >
              Back to Quiz
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Quiz Management */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Quiz Management</h3>
            <div className="space-y-3">
              {quizzes.map(quiz => (
                    <div key={quiz.id} className="p-4 bg-white rounded border">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-lg">{quiz.title}</h4>
                          <p className="text-sm text-gray-600 mb-2">{quiz.description}</p>
                          <div className="mb-2">
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                              {quiz.subject || 'General Knowledge'}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            <span>Created by: {quiz.createdBy}</span>
                        <span>•</span>
                        <span>{quiz.questions ? quiz.questions.length : 0} questions</span>
                        <span>•</span>
                        <span className={`px-2 py-1 rounded ${
                          quiz.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {quiz.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2 ml-4">
                      <button
                        onClick={() => {
                          setEditingQuiz(quiz);
                          setShowQuizEditor(true);
                        }}
                        className="text-blue-600 hover:text-blue-700 text-sm"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => toggleQuizStatus(quiz.id)}
                        className={`text-sm ${
                          quiz.isActive ? 'text-orange-600 hover:text-orange-700' : 'text-green-600 hover:text-green-700'
                        }`}
                      >
                        {quiz.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                      <button
                        onClick={() => deleteQuiz(quiz.id)}
                        className="text-red-600 hover:text-red-700 text-sm"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* User Management */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">User Management</h3>
            <div className="space-y-3">
              {users.map(user => (
                <div key={user.id} className="flex justify-between items-center p-3 bg-white rounded border">
                  <div>
                    <p className="font-medium">{user.username}</p>
                    <p className="text-sm text-gray-600">{user.email}</p>
                    <span className={`text-xs px-2 py-1 rounded ${
                      user.role === 'admin' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {user.role}
                    </span>
                  </div>
                  <button
                    onClick={() => deleteUser(user.id)}
                    disabled={user.id === currentUser.id}
                    className="text-red-600 hover:text-red-700 disabled:opacity-50"
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Quiz creator state
  const [quizData, setQuizData] = useState({
    title: '',
    description: '',
    subject: 'General Knowledge',
    questions: [
      {
        id: 1,
        question: '',
        choices: ['', '', '', ''],
        correctAnswer: ''
      }
    ]
  });

  // Render quiz creator
  const renderQuizCreator = () => {

    const addQuestion = () => {
      setQuizData({
        ...quizData,
        questions: [
          ...quizData.questions,
          {
            id: quizData.questions.length + 1,
            question: '',
            choices: ['', '', '', ''],
            correctAnswer: ''
          }
        ]
      });
    };

    const updateQuestion = (index, field, value) => {
      const updatedQuestions = [...quizData.questions];
      updatedQuestions[index] = { ...updatedQuestions[index], [field]: value };
      setQuizData({ ...quizData, questions: updatedQuestions });
    };

    const updateChoice = (questionIndex, choiceIndex, value) => {
      const updatedQuestions = [...quizData.questions];
      updatedQuestions[questionIndex].choices[choiceIndex] = value;
      setQuizData({ ...quizData, questions: updatedQuestions });
    };

    const removeQuestion = (index) => {
      if (quizData.questions.length > 1) {
        const updatedQuestions = quizData.questions.filter((_, i) => i !== index);
        setQuizData({ ...quizData, questions: updatedQuestions });
      }
    };

    const handleSubmit = (e) => {
      e.preventDefault();
      if (quizData.title && quizData.description && quizData.questions.every(q => q.question && q.choices.every(c => c) && q.correctAnswer)) {
        createQuiz(quizData);
      } else {
        alert('Please fill in all fields');
      }
    };

    return (
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Create New Quiz</h2>
          <button
            onClick={() => setShowQuizCreator(false)}
            className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md"
          >
            Cancel
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            {/* Quiz Details */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quiz Title
              </label>
              <input
                type="text"
                value={quizData.title}
                onChange={(e) => setQuizData({ ...quizData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter quiz title"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                value={quizData.description}
                onChange={(e) => setQuizData({ ...quizData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter quiz description"
                rows="3"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Subject
              </label>
              <select
                value={quizData.subject}
                onChange={(e) => setQuizData({ ...quizData, subject: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                {subjectOptions.map((subject) => (
                  <option key={subject} value={subject}>
                    {subject}
                  </option>
                ))}
              </select>
            </div>

            {/* Questions */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Questions</h3>
                <button
                  type="button"
                  onClick={addQuestion}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm"
                >
                  Add Question
                </button>
              </div>

              <div className="space-y-6">
                {quizData.questions.map((question, qIndex) => (
                  <div key={qIndex} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-medium text-gray-800">Question {qIndex + 1}</h4>
                      {quizData.questions.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeQuestion(qIndex)}
                          className="text-red-600 hover:text-red-700 text-sm"
                        >
                          Remove
                        </button>
                      )}
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Question Text
                        </label>
                        <input
                          type="text"
                          value={question.question}
                          onChange={(e) => updateQuestion(qIndex, 'question', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Enter question"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Answer Choices
                        </label>
                        <div className="space-y-2">
                          {question.choices.map((choice, cIndex) => (
                            <div key={cIndex} className="flex items-center space-x-2">
                              <input
                                type="text"
                                value={choice}
                                onChange={(e) => updateChoice(qIndex, cIndex, e.target.value)}
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder={`Choice ${cIndex + 1}`}
                                required
                              />
                              <input
                                type="radio"
                                name={`correct-${qIndex}`}
                                checked={question.correctAnswer === choice}
                                onChange={() => updateQuestion(qIndex, 'correctAnswer', choice)}
                                className="ml-2"
                              />
                              <span className="text-sm text-gray-600">Correct</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowQuizCreator(false)}
                className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-md"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-md"
              >
                Create Quiz
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  };

  // Render quiz question
  const renderQuestion = () => {
    const currentQuestion = selectedQuiz.questions[currentQuestionIndex];
    
    return (
      <div className="max-w-2xl mx-auto p-8">
        <div className="bg-white rounded-lg shadow-xl p-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <div className="inline-flex items-center bg-blue-50 text-blue-700 px-4 py-2 rounded-full font-medium">
              Time Elapsed: {formatTime(elapsedSeconds)}
            </div>
            <button
              onClick={goToDashboard}
              className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-200"
            >
              Back to Dashboard
            </button>
          </div>

          {/* Progress indicator */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">
                Question {currentQuestionIndex + 1} of {selectedQuiz.questions.length}
              </span>
              <span className="text-sm text-gray-600">
                {Math.round(((currentQuestionIndex + 1) / selectedQuiz.questions.length) * 100)}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentQuestionIndex + 1) / selectedQuiz.questions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Question */}
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            {currentQuestion.question}
          </h2>

          {/* Answer choices */}
          <div className="space-y-3">
            {currentQuestion.choices.map((choice, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(choice)}
                className="w-full p-4 text-left bg-gray-50 hover:bg-blue-50 border border-gray-200 hover:border-blue-300 rounded-lg transition-all duration-200 hover:shadow-md"
              >
                <span className="text-lg text-gray-800">{choice}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  };

  // Render results
  const renderResults = () => {
    const totalQuestions = selectedQuiz ? selectedQuiz.questions.length : 0;
    const percentage = totalQuestions > 0 ? Math.round((score / totalQuestions) * 100) : 0;

    return (
      <div className="max-w-2xl mx-auto p-8">
        <div className="bg-white rounded-lg shadow-xl p-8">
          {/* Score display */}
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Quiz Complete!
            </h2>
            <div className="text-6xl font-bold text-blue-600 mb-2">
              {score}/{selectedQuiz ? selectedQuiz.questions.length : 0}
            </div>
            <div className="text-xl text-gray-600">
              {selectedQuiz && (
                score === selectedQuiz.questions.length ? "Perfect Score! 🎉" : 
                score >= selectedQuiz.questions.length * 0.7 ? "Great Job! 👍" :
                score >= selectedQuiz.questions.length * 0.5 ? "Good Effort! 💪" : "Keep Learning! 📚"
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            <div className="bg-gray-50 rounded-lg p-4 text-center border border-gray-100">
              <p className="text-sm text-gray-500 mb-1">Accuracy</p>
              <p className="text-2xl font-bold text-gray-800">{percentage}%</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center border border-gray-100">
              <p className="text-sm text-gray-500 mb-1">Correct Answers</p>
              <p className="text-2xl font-bold text-gray-800">{score}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center border border-gray-100">
              <p className="text-sm text-gray-500 mb-1">Time Spent</p>
              <p className="text-2xl font-bold text-gray-800">{formatTime(elapsedSeconds)}</p>
            </div>
          </div>

          {/* AI Feedback */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">
              AI Feedback
            </h3>
            {isLoadingFeedback ? (
              <div className="flex items-center justify-center p-6 bg-gray-50 rounded-lg">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span className="ml-3 text-gray-600">Generating feedback...</span>
              </div>
            ) : (
              <div className="p-6 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                <p className="text-gray-800 leading-relaxed">
                  {aiFeedback}
                </p>
              </div>
            )}
          </div>

          {/* Answer review */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">
              Your Answers
            </h3>
            <div className="space-y-3">
              {selectedQuiz && selectedQuiz.questions.map((question, index) => {
                const userAnswer = userAnswers[index];
                const isCorrect = userAnswer === question.correctAnswer;
                
                return (
                  <div key={question.id} className={`p-4 rounded-lg border ${
                    isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                  }`}>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-gray-800 mb-2">
                          {question.question}
                        </p>
                        <p className="text-sm text-gray-600">
                          Your answer: <span className={`font-medium ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
                            {userAnswer}
                          </span>
                        </p>
                        {!isCorrect && (
                          <p className="text-sm text-gray-600 mt-1">
                            Correct answer: <span className="font-medium text-green-600">
                              {question.correctAnswer}
                            </span>
                          </p>
                        )}
                      </div>
                      <div className="ml-4">
                        {isCorrect ? (
                          <span className="text-green-600 text-2xl">✓</span>
                        ) : (
                          <span className="text-red-600 text-2xl">✗</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Reset button */}
          <div className="text-center">
            <div className="flex flex-col sm:flex-row justify-center gap-3">
              <button
                onClick={resetQuiz}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
              >
                Take Quiz Again
              </button>
              <button
                onClick={goToDashboard}
                className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
              >
                Back to Dashboard
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Render user dashboard
  const renderUserDashboard = () => {
    const activeQuizzes = quizzes.filter(quiz => quiz.isActive);
    const availableSubjects = ['All Subjects', ...new Set(activeQuizzes.map((quiz) => quiz.subject || 'General Knowledge'))];
    const filteredQuizzes = activeQuizzes.filter((quiz) => {
      const search = quizSearchTerm.trim().toLowerCase();
      const subjectMatches = selectedSubject === 'All Subjects' || (quiz.subject || 'General Knowledge') === selectedSubject;
      if (!subjectMatches) {
        return false;
      }
      if (!search) {
        return true;
      }

      return (
        quiz.title.toLowerCase().includes(search) ||
        quiz.description.toLowerCase().includes(search) ||
        quiz.createdBy.toLowerCase().includes(search) ||
        (quiz.subject || 'General Knowledge').toLowerCase().includes(search)
      );
    });
    const completedQuizzes = quizHistory.length;
    const averageScore = completedQuizzes > 0
      ? Math.round(
          quizHistory.reduce((total, quiz) => total + ((quiz.score / quiz.totalQuestions) * 100), 0) / completedQuizzes
        )
      : 0;
    const bestScore = completedQuizzes > 0
      ? Math.max(...quizHistory.map((quiz) => Math.round((quiz.score / quiz.totalQuestions) * 100)))
      : 0;
    const strongPerformances = quizHistory.filter((quiz) => (quiz.score / quiz.totalQuestions) >= 0.7).length;
    const focusSubject = selectedSubject === 'All Subjects'
      ? (availableSubjects[1] || 'General Knowledge')
      : selectedSubject;
    const aiReadinessMessage = averageScore >= 80
      ? 'AI can generate harder mixed-difficulty quizzes to keep you challenged.'
      : averageScore >= 60
        ? 'AI can balance revision and new questions so you improve steadily.'
        : 'AI can generate supportive practice sets with simpler warm-up questions and more hints.';
    const aiRecommendation = completedQuizzes === 0
      ? `Start with a short ${focusSubject} diagnostic quiz so AI can learn your baseline.`
      : `Based on your results, AI could build a ${focusSubject} practice set focused on the questions you miss most often.`;
    
    return (
      <div className="max-w-6xl mx-auto p-8">
        <div className="bg-white rounded-lg shadow-xl p-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Welcome, {currentUser.username}!</h2>
              <p className="text-gray-600">Role: {currentUser.role}</p>
            </div>
            <div className="flex space-x-2">
              {currentUser.role === 'admin' && (
                <button
                  onClick={toggleAdminPanel}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md"
                >
                  Admin Panel
                </button>
              )}
              <button
                onClick={handleLogout}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md"
              >
                Logout
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-blue-50 rounded-xl p-5 border border-blue-100">
              <p className="text-sm text-blue-700 mb-1">Active Quizzes</p>
              <p className="text-3xl font-bold text-blue-900">{activeQuizzes.length}</p>
            </div>
            <div className="bg-green-50 rounded-xl p-5 border border-green-100">
              <p className="text-sm text-green-700 mb-1">Quizzes Completed</p>
              <p className="text-3xl font-bold text-green-900">{completedQuizzes}</p>
            </div>
            <div className="bg-amber-50 rounded-xl p-5 border border-amber-100">
              <p className="text-sm text-amber-700 mb-1">Average Score</p>
              <p className="text-3xl font-bold text-amber-900">{averageScore}%</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 mb-6">
            <button
              onClick={() => setDashboardTab('subjects')}
              className={`px-4 py-2 rounded-full font-medium transition-colors duration-200 ${
                dashboardTab === 'subjects'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Subjects
            </button>
            <button
              onClick={() => setDashboardTab('performance')}
              className={`px-4 py-2 rounded-full font-medium transition-colors duration-200 ${
                dashboardTab === 'performance'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Performance
            </button>
            <button
              onClick={() => setDashboardTab('ai-coach')}
              className={`px-4 py-2 rounded-full font-medium transition-colors duration-200 ${
                dashboardTab === 'ai-coach'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              AI Coach
            </button>
          </div>

          <div className="grid grid-cols-1 gap-8">
            {/* Available Quizzes */}
            {dashboardTab === 'subjects' && (
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
                <h3 className="text-xl font-semibold text-gray-800">Available Quizzes</h3>
                <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                  <select
                    value={selectedSubject}
                    onChange={(e) => setSelectedSubject(e.target.value)}
                    className="w-full sm:w-48 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {availableSubjects.map((subject) => (
                      <option key={subject} value={subject}>
                        {subject}
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={quizSearchTerm}
                    onChange={(e) => setQuizSearchTerm(e.target.value)}
                    placeholder="Search quizzes"
                    className="w-full sm:w-60 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              {activeQuizzes.length === 0 ? (
                <p className="text-gray-600">No active quizzes available.</p>
              ) : filteredQuizzes.length === 0 ? (
                <p className="text-gray-600">No quizzes match your subject or search yet.</p>
              ) : (
                <div className="space-y-3">
                  {filteredQuizzes.map(quiz => (
                    <div key={quiz.id} className="p-4 bg-gray-50 rounded-lg border hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-lg text-gray-800">{quiz.title}</h4>
                          <p className="text-sm text-gray-600 mb-2">{quiz.description}</p>
                          <div className="mb-2">
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                              {quiz.subject || 'General Knowledge'}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            <span>{quiz.questions ? quiz.questions.length : 0} questions</span>
                            <span>•</span>
                            <span>Created by: {quiz.createdBy}</span>
                          </div>
                        </div>
                        <button
                          onClick={() => startQuiz(quiz)}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm"
                        >
                          Start Quiz
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            )}

            {/* Quiz History */}
            {dashboardTab === 'performance' && (
            <div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                  <p className="text-sm text-slate-600 mb-1">Best Score</p>
                  <p className="text-3xl font-bold text-slate-900">{bestScore}%</p>
                </div>
                <div className="bg-emerald-50 rounded-xl p-5 border border-emerald-100">
                  <p className="text-sm text-emerald-700 mb-1">Strong Performances</p>
                  <p className="text-3xl font-bold text-emerald-900">{strongPerformances}</p>
                </div>
                <div className="bg-violet-50 rounded-xl p-5 border border-violet-100">
                  <p className="text-sm text-violet-700 mb-1">Attempts Recorded</p>
                  <p className="text-3xl font-bold text-violet-900">{completedQuizzes}</p>
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Your Quiz History</h3>
              {quizHistory.length === 0 ? (
                <p className="text-gray-600">No quizzes taken yet. Start your first quiz!</p>
              ) : (
                <div className="space-y-3">
                  {quizHistory.slice().reverse().map((quiz) => (
                    <div key={quiz.id} className="p-4 bg-gray-50 rounded-lg border">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{quiz.quizTitle}</p>
                          <p className="text-sm text-gray-600">
                            {new Date(quiz.date).toLocaleDateString()} - Score: {quiz.score}/{quiz.totalQuestions}
                          </p>
                        </div>
                        <span className={`px-3 py-1 rounded text-sm ${
                          quiz.score === quiz.totalQuestions ? 'bg-green-100 text-green-800' :
                          quiz.score >= quiz.totalQuestions * 0.7 ? 'bg-blue-100 text-blue-800' :
                          quiz.score >= quiz.totalQuestions * 0.5 ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {Math.round((quiz.score / quiz.totalQuestions) * 100)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            )}

            {dashboardTab === 'ai-coach' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-sky-50 via-indigo-50 to-violet-50 rounded-2xl border border-indigo-100 p-6">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">AI Can Personalize Your Quiz Journey</h3>
                    <p className="text-gray-700 leading-relaxed">
                      Once an API key is added, the AI coach can create quizzes based on your selected subject, your recent scores,
                      and the areas where you need more practice.
                    </p>
                  </div>
                  <div className="bg-white/80 rounded-xl px-4 py-3 border border-white shadow-sm">
                    <p className="text-xs uppercase tracking-wide text-indigo-600 font-semibold mb-1">Current Focus</p>
                    <p className="text-lg font-bold text-gray-900">{focusSubject}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white border border-gray-200 rounded-xl p-5">
                  <p className="text-sm text-gray-500 mb-1">Selected Subject</p>
                  <p className="text-2xl font-bold text-gray-900">{focusSubject}</p>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-5">
                  <p className="text-sm text-gray-500 mb-1">Average Performance</p>
                  <p className="text-2xl font-bold text-gray-900">{averageScore}%</p>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-5">
                  <p className="text-sm text-gray-500 mb-1">Practice Direction</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {completedQuizzes === 0 ? 'Starter Mode' : averageScore >= 70 ? 'Challenge Mode' : 'Revision Mode'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-gray-50 rounded-xl border border-gray-200 p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">How AI Would Help</h4>
                  <div className="space-y-3 text-gray-700">
                    <p>{aiReadinessMessage}</p>
                    <p>{aiRecommendation}</p>
                    <p>
                      It can also vary quiz difficulty, focus on weaker concepts, and generate follow-up practice in
                      subjects like {focusSubject} after each attempt.
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-xl border border-gray-200 p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">Example AI Actions</h4>
                  <div className="space-y-3 text-gray-700">
                    <p>Generate a new {focusSubject} quiz tailored to your current level.</p>
                    <p>Create revision quizzes from topics where your score dropped below 70%.</p>
                    <p>Mix easier and harder questions depending on your recent quiz history.</p>
                    <p>Recommend the next subject to practice based on your strongest and weakest results.</p>
                  </div>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
                <h4 className="text-lg font-semibold text-amber-900 mb-2">AI Setup Status</h4>
                <p className="text-amber-800">
                  The AI coach UI is ready. Add an API key later and this tab can evolve from guidance into actual
                  AI-generated personalized quizzes.
                </p>
              </div>
            </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // Main render logic
  if (!isAuthenticated) {
    return renderAuthForm();
  }

  if (showQuizCreator) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500">
        <div className="container mx-auto px-4 py-8">
          {renderQuizCreator()}
        </div>
      </div>
    );
  }

  if (showAdminPanel) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500">
        <div className="container mx-auto px-4 py-8">
          {renderAdminPanel()}
        </div>
      </div>
    );
  }

  if (quizCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500">
        <div className="container mx-auto px-4 py-8">
          {renderResults()}
        </div>
      </div>
    );
  }

  if (selectedQuiz) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500">
        <div className="container mx-auto px-4 py-8">
          {/* Header with user info */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">
              {selectedQuiz.title}
            </h1>
            <p className="text-white/80 text-lg">
              Welcome, {currentUser.username}! ({currentUser.role})
            </p>
          </div>
          {renderQuestion()}
        </div>
      </div>
    );
  }

  // Default: User dashboard
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500">
      <div className="container mx-auto px-4 py-8">
        {renderUserDashboard()}
      </div>
    </div>
  );
}

export default App; 
