ALTER TABLE quizzes
ADD COLUMN subject VARCHAR(100) NOT NULL DEFAULT 'General';

UPDATE quizzes
SET subject = CASE
    WHEN LOWER(title) LIKE '%math%' THEN 'Mathematics'
    WHEN LOWER(title) LIKE '%science%' THEN 'Science'
    WHEN LOWER(title) LIKE '%computer%' OR LOWER(description) LIKE '%java%' OR LOWER(description) LIKE '%python%' THEN 'Computer Science'
    WHEN LOWER(title) LIKE '%geography%' THEN 'Geography'
    ELSE 'General Knowledge'
END;
