package com.example.quizserver.ai;

public record AiFeedbackAnswer(
        String question,
        String userAnswer,
        String correctAnswer,
        boolean correct
) {
}
