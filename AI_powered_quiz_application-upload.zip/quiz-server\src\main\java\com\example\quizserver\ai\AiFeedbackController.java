package com.example.quizserver.ai;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/ai")
public class AiFeedbackController {
    private final OpenAiFeedbackService openAiFeedbackService;

    public AiFeedbackController(OpenAiFeedbackService openAiFeedbackService) {
        this.openAiFeedbackService = openAiFeedbackService;
    }

    @PostMapping("/feedback")
    public ResponseEntity<Map<String, String>> generateFeedback(@RequestBody AiFeedbackRequest request) {
        String feedback = openAiFeedbackService.generateFeedback(request);
        return ResponseEntity.ok(Map.of("feedback", feedback));
    }
}
