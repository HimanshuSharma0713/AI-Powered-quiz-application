package com.example.quizserver.ai;

import java.util.List;

public record AiFeedbackRequest(
        String quizTitle,
        Integer score,
        Integer totalQuestions,
        List<AiFeedbackAnswer> answers
) {
}
