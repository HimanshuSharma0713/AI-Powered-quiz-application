$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$javaHome = Join-Path $projectRoot '.tools\jdk-extract\jdk-17.0.18+8'
$mavenCmd = Join-Path $projectRoot '.tools\maven-extract\apache-maven-3.9.14\bin\mvn.cmd'
$localRepo = Join-Path $PSScriptRoot '.m2\repository'
$logFile = Join-Path $PSScriptRoot 'backend-local.out.log'

$env:JAVA_HOME = $javaHome
$env:USERPROFILE = $PSScriptRoot
$env:HOME = $PSScriptRoot

New-Item -ItemType Directory -Force -Path $localRepo | Out-Null

Set-Location $PSScriptRoot
& $mavenCmd "-Dmaven.repo.local=$localRepo" 'spring-boot:run' *> $logFile
